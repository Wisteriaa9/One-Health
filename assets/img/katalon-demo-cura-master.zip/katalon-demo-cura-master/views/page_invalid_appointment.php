<section id="invalid-appointment" class="section bg-primary">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2>Make Appointment</h2>
                <hr class="small">
            </div>
            <div class="col-lg-12">
                <p class="lead text-danger">Error: Invalid appointment!</p>
            </div>
            <div class="col-lg-12">
                <p class="text-center"><a class="btn btn-default" href="<?php echo SITE_URL; ?>">Go to Homepage</a></p>
            </div>
        </div>
    </div>
</section>
