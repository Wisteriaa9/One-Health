<section id="profile" class="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2>Profile</h2>
                <p class="lead">Under construction.</p>
                <p class="lead"><a class="btn btn-default" href="<?php echo SITE_URL.'authenticate.php?logout'; ?>">Logout</a></p>
            </div>
        </div>
    </div>
</section>
